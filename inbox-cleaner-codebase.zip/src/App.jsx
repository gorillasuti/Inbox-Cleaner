import React, { useState, useEffect, useRef } from 'react';
import { X, Trash2, RefreshCw, ShieldAlert, Moon, Sun, Info, Crown, Check, Lock, User, Settings, LogOut, Mail, Zap, Globe, CreditCard, AlertCircle, ChevronDown, ChevronRight, Eye, EyeOff, RotateCcw, HelpCircle, Bug, Send, MoreHorizontal, Clock, ShieldCheck, Archive, ChevronUp, Minus } from 'lucide-react';
import Tippy from '@tippyjs/react';
import Draggable from 'react-draggable';
import Lottie from 'lottie-react';
import { scanInbox } from './utils/scanner';
import { GmailService } from './utils/gmail-service';
import { groupItems } from './utils/grouping';
import { getToken } from './utils/oauth';
import { ConfirmationModal } from './components/ConfirmationModal';

import { useAuth } from './contexts/AuthContext';
import { translations } from './utils/translations';
import confettiData from './assets/confetti.json';
import sadData from './assets/sad.json';
import UnsubscribeOverlay from './components/UnsubscribeOverlay';
import OnboardingFlow from './components/OnboardingFlow';
import HelpView from './components/HelpView';
import { supabase } from './lib/supabase';
import { isProviderConnected, disconnectProvider, authenticateProvider, getConnectedProviders } from './utils/oauth';
import { unsubscribeFromSender } from './utils/unsubscribe';

// --- Components ---

const Toast = ({ message, type, onClose }) => {
    useEffect(() => {
        const timer = setTimeout(onClose, 2000); // Shorter timeout
        return () => clearTimeout(timer);
    }, [onClose]);

    if (type === 'logout') {
        return (
            <div className="absolute inset-0 z-[2147483649] flex items-center justify-center bg-white/50 dark:bg-black/50 backdrop-blur-sm animate-in fade-in duration-300">
                <div className="bg-zinc-100 dark:bg-zinc-800 px-6 py-4 rounded-xl shadow-xl flex flex-col items-center gap-3 border border-zinc-200 dark:border-zinc-700">
                    <div className="p-3 bg-zinc-200 dark:bg-zinc-700 rounded-full text-zinc-600 dark:text-zinc-300">
                        <LogOut size={20} />
                    </div>
                    <span className="font-medium text-sm text-zinc-800 dark:text-zinc-200">{message}</span>
                </div>
            </div>
        );
    }

    const bgColors = {
        success: 'bg-emerald-500',
        error: 'bg-red-500',
        info: 'bg-zinc-800 dark:bg-zinc-700'
    };

    return (
        <div
            onClick={onClose}
            className={`absolute bottom-4 left-1/2 -translate-x-1/2 z-[2147483648] flex items-center gap-3 px-6 py-4 rounded-2xl shadow-2xl text-white text-sm font-medium animate-in slide-in-from-bottom-4 fade-in duration-300 cursor-pointer hover:scale-105 transition-all w-[90%] max-w-sm whitespace-normal break-words text-center border border-white/10 backdrop-blur-md ${bgColors[type] || bgColors.info}`}
        >
            {type === 'success' && <Check size={20} className="text-white flex-shrink-0" />}
            {type === 'error' && <AlertCircle size={20} className="text-white flex-shrink-0" />}
            {type === 'info' && <Info size={20} className="text-white flex-shrink-0" />}
            <span className="flex-1">{message}</span>
        </div>
    );
};

const ScanningOverlay = ({ mode, isPremium, t }) => (
    <div className={`absolute inset-0 z-50 flex flex-col items-center justify-center text-white animate-in fade-in duration-300 ${isPremium && mode === 'full' ? 'bg-indigo-900/95' : 'bg-emerald-500/95'} backdrop-blur-sm`}>
        <div className="relative w-32 h-32 mb-8">
            {/* Premium vs Standard Animation */}
            <div className="absolute inset-0 flex items-center justify-center">
                {isPremium && mode === 'full' ? (
                    <>
                        {/* Premium Sparkle Animation */}
                        <div className="absolute inset-0 rounded-full border-4 border-violet-400/20 animate-[ping_3s_cubic-bezier(0,0,0.2,1)_infinite]" />
                        <div className="w-24 h-24 bg-violet-500/20 rounded-full animate-pulse absolute blur-xl" />
                        <Crown size={48} className="text-violet-400 relative z-10 drop-shadow-[0_0_15px_rgba(167,139,250,0.5)]" />
                    </>
                ) : (
                    <>
                        <div className="w-24 h-24 bg-white/20 rounded-full animate-ping absolute" />
                        <div className="w-20 h-20 bg-white/30 rounded-full animate-pulse absolute" />
                        <RefreshCw size={48} className="animate-spin relative z-10" />
                    </>
                )}
            </div>


        </div>
        <h3 className="text-2xl font-bold mb-2">{t.cleaning}</h3>
        <p className="opacity-80 text-sm max-w-[200px] text-center">
            {isPremium && mode === 'full' ? t.premiumCleaningDesc : (mode === 'quick' ? t.quickCleaningDesc : t.deepCleaningDesc)}
        </p>
    </div>
);

const DeleteSuccessOverlay = ({ t }) => (
    <div className="absolute inset-0 z-[100] flex flex-col items-center justify-center bg-white/80 dark:bg-black/80 backdrop-blur-md animate-in fade-in duration-500">
        <div className="bg-white dark:bg-zinc-900 p-8 rounded-2xl shadow-2xl border border-zinc-200 dark:border-zinc-800 flex flex-col items-center text-center max-w-sm mx-4 animate-in zoom-in-95 duration-300 delay-100">
            <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mb-4 text-red-500 dark:text-red-400">
                <Trash2 size={32} />
            </div>
            <h2 className="text-2xl font-bold text-zinc-900 dark:text-white mb-2">{t.accountDeleted}</h2>
            <p className="text-zinc-600 dark:text-zinc-400 text-center px-8">
                {t.accountDeletedDesc}
            </p>
            <div className="mt-6 flex items-center gap-2 text-xs text-zinc-400">
                <LogOut size={12} />
                <span>Logging out...</span>
            </div>
        </div>
    </div>
);

const AuthView = ({ onClose, t }) => {
    const [isLogin, setIsLogin] = useState(true);
    const [email, setEmail] = useState('');
    const [fullName, setFullName] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [error, setError] = useState('');
    const { login, register, loginWithGoogle } = useAuth();

    // Password Validation Logic
    const hasLength = password.length >= 8;
    const hasNumber = /\d/.test(password);
    const hasSpecial = /[!@#$%^&*(),.?":{ }|<>]/.test(password);
    const isStrong = hasLength && hasNumber && hasSpecial;

    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setIsSubmitting(true);

        if (!isLogin) {
            if (password !== confirmPassword) {
                setError(t.passwordsNoMatch);
                setIsSubmitting(false);
                return;
            }
            if (!isStrong) {
                setError(t.passwordReq);
                setIsSubmitting(false);
                return;
            }
        }

        try {
            if (isLogin) await login(email, password);
            else await register(email, password, fullName);
            onClose();
        } catch (err) {
            console.error("Auth error:", err);
            if (err.message === "User already registered") {
                setError(t.accountExists);
                setIsLogin(true);
            } else {
                setError(t.authFailed);
            }
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="bg-white dark:bg-zinc-950 flex flex-col p-6 animate-in slide-in-from-right duration-300 h-full min-h-[350px]">
            <div className="flex justify-between items-center mb-8">
                <h2 className="text-xl font-bold tracking-tight text-zinc-900 dark:text-white">{isLogin ? t.welcomeBack : t.createAccount}</h2>
                <button onClick={onClose} className="hover:bg-gray-100 dark:hover:bg-zinc-800 p-1 rounded-full transition-colors text-zinc-900 dark:text-white"><X size={20} /></button>
            </div>

            {error && (
                <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 text-sm rounded-lg flex items-center gap-2">
                    <AlertCircle size={16} />
                    {error}
                </div>
            )}

            <form onSubmit={handleSubmit} className="flex flex-col gap-4">
                {!isLogin && (
                    <div className="space-y-1 animate-in fade-in slide-in-from-top-2 duration-200">
                        <label className="text-xs font-medium opacity-70 ml-1 text-zinc-900 dark:text-white">{t.fullName}</label>
                        <input
                            type="text"
                            placeholder={t.fullName}
                            className="w-full p-3 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-transparent text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all"
                            value={fullName}
                            onChange={e => setFullName(e.target.value)}
                            required
                            disabled={isSubmitting}
                        />
                    </div>
                )}
                <div className="space-y-1">
                    <label className="text-xs font-medium opacity-70 ml-1 text-zinc-900 dark:text-white">{t.email}</label>
                    <input
                        type="email"
                        placeholder="name@example.com"
                        className="w-full p-3 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-transparent text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all"
                        value={email}
                        onChange={e => setEmail(e.target.value)}
                        required
                        disabled={isSubmitting}
                    />
                </div>
                <div className="space-y-1">
                    <label className="text-xs font-medium opacity-70 ml-1 text-zinc-900 dark:text-white">{t.password}</label>
                    <div className="relative">
                        <input
                            type={showPassword ? "text" : "password"}
                            placeholder="••••••••"
                            className="w-full p-3 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-transparent text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all pr-10"
                            value={password}
                            onChange={e => setPassword(e.target.value)}
                            required
                            disabled={isSubmitting}
                        />
                        <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-3 top-1/2 -translate-y-1/2 opacity-50 hover:opacity-100 text-zinc-900 dark:text-white"
                        >
                            {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                        </button>
                    </div>

                    {/* Password Strength Indicators (Only on Signup) */}
                    {!isLogin && (
                        <div className="flex flex-wrap gap-2 mt-2 px-1">
                            <div className={`text-[10px] flex items-center gap-1 ${hasLength ? 'text-emerald-500 font-medium' : 'text-zinc-400'}`}>
                                {hasLength ? <Check size={10} /> : <div className="w-2.5 h-2.5 rounded-full border border-zinc-300 dark:border-zinc-700" />}
                                8+ Chars
                            </div>
                            <div className={`text-[10px] flex items-center gap-1 ${hasNumber ? 'text-emerald-500 font-medium' : 'text-zinc-400'}`}>
                                {hasNumber ? <Check size={10} /> : <div className="w-2.5 h-2.5 rounded-full border border-zinc-300 dark:border-zinc-700" />}
                                Number
                            </div>
                            <div className={`text-[10px] flex items-center gap-1 ${hasSpecial ? 'text-emerald-500 font-medium' : 'text-zinc-400'}`}>
                                {hasSpecial ? <Check size={10} /> : <div className="w-2.5 h-2.5 rounded-full border border-zinc-300 dark:border-zinc-700" />}
                                Special
                            </div>
                        </div>
                    )}
                </div>

                {!isLogin && (
                    <div className="space-y-1 animate-in fade-in slide-in-from-top-2 duration-200">
                        <label className="text-xs font-medium opacity-70 ml-1 text-zinc-900 dark:text-white">Confirm Password</label>
                        <div className="relative">
                            <input
                                type={showPassword ? "text" : "password"}
                                placeholder={t.confirmPassword}
                                className="w-full p-3 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-transparent text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all"
                                value={confirmPassword}
                                onChange={e => setConfirmPassword(e.target.value)}
                                required
                                disabled={isSubmitting}
                            />
                        </div>
                    </div>
                )}

                <button 
                    disabled={isSubmitting}
                    className="mt-2 bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900 py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity shadow-sm overflow-hidden relative flex items-center justify-center gap-2"
                >
                    {isSubmitting && <RefreshCw size={16} className="animate-spin" />}
                    {isLogin ? t.login : t.signup}
                </button>

                <div className="relative flex items-center py-2">
                    <div className="flex-grow border-t border-zinc-200 dark:border-zinc-800"></div>
                    <span className="flex-shrink-0 mx-4 text-xs opacity-50 text-zinc-900 dark:text-white">{t.or}</span>
                    <div className="flex-grow border-t border-zinc-200 dark:border-zinc-800"></div>
                </div>

                <button 
                    type="button" 
                    onClick={() => loginWithGoogle()} 
                    disabled={isSubmitting}
                    className="flex items-center justify-center gap-2 w-full py-3 rounded-lg border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-50 dark:hover:bg-zinc-900 transition-colors text-zinc-900 dark:text-white font-medium text-sm"
                >
                    <svg className="w-4 h-4" viewBox="0 0 24 24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" /><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" /><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" /><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" /></svg>
                    {t.googleLogin}
                </button>
            </form>

            <div className="mt-auto text-center pt-4">
                <p className="text-sm opacity-60 text-zinc-900 dark:text-white">
                    {isLogin ? t.noAccount : t.hasAccount}
                    <button onClick={() => { setIsLogin(!isLogin); setError(''); }} className="text-emerald-600 dark:text-emerald-400 font-bold hover:underline">
                        {isLogin ? t.signup : t.login}
                    </button>
                </p>
            </div>
        </div>
    );
};

const SubscriptionView = ({ onClose, lang, setLang, t, setView, setToast, onCancel, onResume }) => {
    const { user, isPremium, refreshProfile, resumeSubscription, cancelSubscription, createPortalSession, addToHistory } = useAuth();
    const [isRestoring, setIsRestoring] = useState(false);
    const [isResuming, setIsResuming] = useState(false);
    const [isManagingPayment, setIsManagingPayment] = useState(false);
    const [showCancelConfirm, setShowCancelConfirm] = useState(false);
    const [isCancelling, setIsCancelling] = useState(false);

    const handleResume = async () => {
        setIsResuming(true);
        try {
            await resumeSubscription();
            // Toast removed in favor of popup
            if (onResume) onResume(); 
            onClose();
        } catch (error) {
            setToast({ message: t.failedResumeSub, type: 'error' });
        } finally {
            setIsResuming(false);
        }
    };

    const handleManagePayment = async () => {
        setIsManagingPayment(true);
        try {
            await createPortalSession();
        } catch (error) {
            console.error("Failed to open portal:", error);
            setToast({ message: t.failedOpenPortal, type: 'error' });
        } finally {
            setIsManagingPayment(false);
        }
    };

    const handleCancel = async () => {
        setIsCancelling(true);
        try {
            await cancelSubscription();
            setToast({ message: t.subCanceled, type: 'info' });
            if (onCancel) onCancel();
            onClose();
        } catch (error) {
            console.error("Cancel failed:", error);
            setToast({ message: error.message || t.failedCancelSub, type: 'error' });
        } finally {
            setIsCancelling(false);
        }
    };

    if (showCancelConfirm) {
        return (
            <div className="bg-white dark:bg-zinc-950 flex flex-col p-6 animate-in slide-in-from-right duration-300 h-full">
                <div className="flex justify-between items-center mb-8">
                    <h2 className="text-base font-semibold tracking-tight text-zinc-900 dark:text-white">{t.cancelSubConfirm}</h2>
                    <button onClick={() => setShowCancelConfirm(false)} className="hover:bg-gray-100 dark:hover:bg-zinc-800 p-1 rounded-md transition-colors text-zinc-500 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-white"><X size={18} /></button>
                </div>
                
                <div className="flex-1 flex flex-col items-center justify-center text-center gap-4 px-4 mt-4 mb-4">
                    <div className="w-16 h-16 bg-red-50 dark:bg-red-900/20 rounded-full flex items-center justify-center text-red-500 mb-2">
                        <AlertCircle size={32} />
                    </div>
                    <p className="text-sm text-zinc-600 dark:text-zinc-300 leading-relaxed">
                        {t.cancelSubWarning}
                    </p>
                </div>

                <div className="flex flex-col gap-3 mt-auto">
                    <button 
                        onClick={handleCancel} 
                        disabled={isCancelling}
                        className="w-full h-10 bg-red-500 hover:bg-red-600 text-white text-sm font-medium rounded-lg transition-colors flex items-center justify-center gap-2 shadow-sm"
                    >
                        {isCancelling ? <RefreshCw size={16} className="animate-spin" /> : t.confirmCancellation}
                    </button>
                    <button 
                        onClick={() => setShowCancelConfirm(false)} 
                        disabled={isCancelling}
                        className="w-full h-10 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-50 dark:hover:bg-zinc-800 text-zinc-900 dark:text-white text-sm font-medium rounded-lg transition-colors"
                    >
                        {t.keepSubscription}
                    </button>
                </div>
            </div>
        );
    }

    return (
        <div className="bg-white dark:bg-zinc-950 flex flex-col p-6 animate-in slide-in-from-right duration-300 overflow-y-auto min-h-[400px] w-full h-full">
            <div className="flex justify-between items-center mb-6">
                    <div className="flex flex-col gap-1">
                        <h2 className="text-lg font-bold text-zinc-900 dark:text-white">{t.manageSub}</h2>
                        <p className="text-xs text-zinc-500 dark:text-zinc-400">{t.subDesc}</p>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-full transition-colors text-zinc-500 dark:text-zinc-400">
                        <X size={20} />
                    </button>
                </div>

                {/* Current Plan Section */}
                <div className="bg-zinc-50 dark:bg-zinc-900/50 rounded-xl p-4 border border-zinc-200 dark:border-zinc-800 mb-6">
                    <h3 className="text-xs font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider mb-3">{t.currentPlan}</h3>
                    
                    <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-3">
                            <div className={`p-2 rounded-lg ${isPremium ? 'bg-gradient-to-br from-violet-500 to-fuchsia-500 text-white' : 'bg-zinc-200 dark:bg-zinc-700 text-zinc-500 dark:text-zinc-400'}`}>
                                {isPremium ? <Crown size={20} /> : <User size={20} />}
                            </div>
                            <div>
                                <div className="font-bold text-zinc-900 dark:text-white text-base">
                                    {isPremium ? t.proPlan : t.freePlan}
                                </div>
                                <div className="text-xs text-zinc-500 dark:text-zinc-400">
                                    {isPremium ? t.proPlanPrice : t.freePlanAccess}
                                </div>
                            </div>
                        </div>
                        {isPremium && (
                            <span className={`px-2 py-1 rounded-md text-[10px] font-bold uppercase ${user?.cancel_at_period_end ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-500' : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-500'}`}>
                                {user?.cancel_at_period_end ? t.cancelsSoon : t.active}
                            </span>
                        )}
                    </div>

                    {isPremium && (
                        <div className="space-y-3">
                            <div className="flex justify-between items-center text-sm border-t border-zinc-200 dark:border-zinc-800 pt-3">
                                <span className="text-zinc-500 dark:text-zinc-400">{user?.cancel_at_period_end ? t.expires : t.renews}</span>
                                <span className="font-medium text-zinc-900 dark:text-white">
                                    {user?.subscription_end_date ? formatDate(user.subscription_end_date) : 'Dec 25, 2025'}
                                </span>
                            </div>
                            
                            <div className="flex gap-2 pt-2">
                                <button 
                                    onClick={handleManagePayment} 
                                    disabled={isManagingPayment}
                                    className="flex-1 h-9 bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-lg text-xs font-medium hover:bg-zinc-50 dark:hover:bg-zinc-700 transition-colors text-zinc-900 dark:text-white shadow-sm flex items-center justify-center gap-2"
                                >
                                    {isManagingPayment ? <RefreshCw size={14} className="animate-spin" /> : t.updatePayment}
                                </button>
                                {user?.cancel_at_period_end ? (
                                    <button 
                                        onClick={handleResume} 
                                        disabled={isResuming}
                                        className="flex-1 h-9 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg text-xs font-medium transition-colors shadow-sm flex items-center justify-center gap-2"
                                    >
                                        {isResuming ? <RefreshCw size={14} className="animate-spin" /> : t.resumeSub}
                                    </button>
                                ) : (
                                    <button onClick={() => setShowCancelConfirm(true)} className="flex-1 h-9 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/10 rounded-lg text-xs font-medium transition-colors">
                                        {t.cancelSub}
                                    </button>
                                )}
                            </div>
                        </div>
                    )}
                </div>

                {/* Upgrade Section (Only if not premium) */}
                {!isPremium && (
                    <div className="bg-gradient-to-br from-zinc-900 to-zinc-800 dark:from-zinc-800 dark:to-zinc-900 rounded-xl p-5 text-white shadow-lg relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-4 opacity-10">
                            <Crown size={120} />
                        </div>
                        
                        <div className="relative z-10">
                            <h3 className="text-lg font-bold mb-1">{t.upgradeToPro}</h3>
                            <p className="text-zinc-400 text-xs mb-4">{t.upgradeToProDesc}</p>
                            
                            <div className="space-y-3 mb-6">
                                <div className="flex items-center gap-3 text-sm">
                                    <div className="p-1 bg-emerald-500/20 rounded-full text-emerald-400"><Check size={14} /></div>
                                    <span className="text-zinc-200">{t.unlimitedDeepScanning}</span>
                                </div>
                                <div className="flex items-center gap-3 text-sm">
                                    <div className="p-1 bg-emerald-500/20 rounded-full text-emerald-400"><Check size={14} /></div>
                                    <span className="text-zinc-200">{t.oneClickUnsubscribe}</span>
                                </div>
                                <div className="flex items-center gap-3 text-sm">
                                    <div className="p-1 bg-emerald-500/20 rounded-full text-emerald-400"><Check size={14} /></div>
                                    <span className="text-zinc-200">{t.prioritySupport}</span>
                                </div>
                                <div className="flex items-center gap-3 text-sm">
                                    <div className="p-1 bg-emerald-500/20 rounded-full text-emerald-400"><Check size={14} /></div>
                                    <span className="text-zinc-200">{t.premiumEmailProviders}</span>
                                </div>
                            </div>

                            <button 
                                onClick={async () => {
                                    try {
                                        const response = await fetch(`${import.meta.env.VITE_API_URL}/api/checkout`, {
                                            method: 'POST',
                                            headers: { 'Content-Type': 'application/json' },
                                            body: JSON.stringify({ userId: user.id })
                                        });
                                        const data = await response.json();
                                        if (data.url) window.open(data.url, '_blank');
                                    } catch (error) {
                                        console.error('Checkout error:', error);
                                        setToast({ message: t.checkoutFailed, type: 'error' });
                                    }
                                }}
                                className="w-full flex-[1.2] bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white py-3 rounded-xl font-semibold flex justify-center items-center gap-2 transition-all active:scale-95 disabled:opacity-70 relative overflow-hidden group shadow-lg shadow-indigo-500/20 whitespace-normal h-auto min-h-[48px]"
                                >
                                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
                                    <Crown size={18} className="text-yellow-300 flex-shrink-0" /> <span className="text-center leading-tight">{t.deepScan}</span>
                                </button>
                            <p className="text-[10px] text-center mt-3 text-zinc-500">{t.cancelAnytimeStripe}</p>
                        </div>
                    </div>
                )}
            </div>

    );
};

const HistoryView = ({ onClose, t, appRef }) => {
    const { history, removeFromHistory, clearHistory } = useAuth();
    const appendTo = () => appRef?.current || document.body;
    const [activeTab, setActiveTab] = useState('unsubscribed');
    const [expandedGroups, setExpandedGroups] = useState(new Set());
    const [selectedItems, setSelectedItems] = useState(new Set());
    const [activeActionMenu, setActiveActionMenu] = useState(null);

    // Clear selection when tab changes
    useEffect(() => {
        setSelectedItems(new Set());
    }, [activeTab]);

    // Group history items
    const groupedHistory = React.useMemo(() => {
        // Filter by tab (future proofing)
        // For now, assume all history is 'unsubscribed' unless we add a type field
        const filtered = history.filter(item => {
            if (activeTab === 'unsubscribed') return ['auto', 'manual', 'post', 'mailto', 'get'].includes(item.method);
            if (activeTab === 'readLater') return item.method === 'read_later';
            if (activeTab === 'keepNewest') return item.method === 'keep_newest';
            if (activeTab === 'trusted') return item.method === 'trust';
            return false;
        });
        return groupItems(filtered);
    }, [history, activeTab]);

    const toggleGroup = (groupId) => {
        const newExpanded = new Set(expandedGroups);
        if (newExpanded.has(groupId)) {
            newExpanded.delete(groupId);
        } else {
            newExpanded.add(groupId);
        }
        setExpandedGroups(newExpanded);
    };

    const toggleSelection = (id) => {
        const newSelected = new Set(selectedItems);
        if (newSelected.has(id)) {
            newSelected.delete(id);
        } else {
            newSelected.add(id);
        }
        setSelectedItems(newSelected);
    };

    const toggleGroupSelection = (group) => {
        const newSelected = new Set(selectedItems);
        // Check if all items in group are selected
        const allIds = group.senders.flatMap(s => s.ids);
        const allSelected = allIds.every(id => newSelected.has(id));

        if (allSelected) {
            allIds.forEach(id => newSelected.delete(id));
        } else {
            allIds.forEach(id => newSelected.add(id));
        }
        setSelectedItems(newSelected);
    };

    const handleBulkAction = async (action) => {
        const itemsToProcess = history.filter(item => selectedItems.has(item.id));
        if (itemsToProcess.length === 0) return;

        if (action === 'delete') {
            for (const item of itemsToProcess) {
                await removeFromHistory(item.id);
            }
            setSelectedItems(new Set());
        }
    };

    const tabs = [
        { id: 'unsubscribed', label: 'Unsubscribed', icon: <Mail size={14} /> },
        { id: 'readLater', label: 'Read Later', icon: <Clock size={14} /> },
        { id: 'keepNewest', label: 'Keep Newest', icon: <Archive size={14} /> },
        { id: 'trusted', label: 'Trusted', icon: <ShieldCheck size={14} /> }
    ];

    return (
        <div className="bg-white dark:bg-zinc-950 flex flex-col h-full animate-in slide-in-from-right duration-300">
            {/* Header */}
            <div className="p-6 border-b border-zinc-100 dark:border-zinc-800 flex justify-between items-center">
                <div className="flex items-center gap-2">
                    <h2 className="text-xl font-bold tracking-tight text-zinc-900 dark:text-white">History</h2>
                    <Tippy content="Manage your past actions." appendTo={appendTo} placement="top" zIndex={999999}>
                        <div className="opacity-50 hover:opacity-100 transition-opacity cursor-help"><Info size={16} /></div>
                    </Tippy>
                </div>
                <button onClick={onClose} className="hover:bg-gray-100 dark:hover:bg-zinc-800 p-1 rounded-full transition-colors text-zinc-900 dark:text-white"><X size={20} /></button>
            </div>

            {/* Tabs */}
            <div className="flex overflow-x-auto px-6 py-2 gap-2 border-b border-zinc-100 dark:border-zinc-800 scrollbar-hide">
                {tabs.map(tab => (
                    <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id)}
                        className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-colors ${
                            activeTab === tab.id 
                                ? 'bg-zinc-900 dark:bg-white text-white dark:text-zinc-900' 
                                : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-200 dark:hover:bg-zinc-700'
                        }`}
                    >
                        {tab.icon}
                        {tab.label}
                    </button>
                ))}
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-6 pb-24">
                {groupedHistory.length === 0 ? (
                    <div className="text-center py-10 text-zinc-400">
                        <p>No items in {tabs.find(t => t.id === activeTab)?.label}.</p>
                    </div>
                ) : (
                    <div className="space-y-3">
                        {groupedHistory.map(group => {
                            const allIds = group.senders.flatMap(s => s.ids);
                            const isAllSelected = allIds.every(id => selectedItems.has(id));
                            const isSomeSelected = allIds.some(id => selectedItems.has(id));

                            return (
                                <div key={group.id} className="border border-zinc-100 dark:border-zinc-800 rounded-xl bg-zinc-50 dark:bg-zinc-900/30 overflow-hidden">
                                    {/* Group Header */}
                                    <div 
                                        className="flex items-center p-3 gap-3 cursor-pointer hover:bg-zinc-100 dark:hover:bg-zinc-800/50 transition-colors"
                                        onClick={(e) => {
                                            // Prevent toggle if clicking checkbox
                                            if (e.target.closest('.checkbox-area')) return;
                                            toggleGroup(group.id);
                                        }}
                                    >
                                        <div className="checkbox-area" onClick={(e) => e.stopPropagation()}>
                                            <div 
                                                onClick={() => toggleGroupSelection(group)}
                                                className={`w-5 h-5 rounded-md border-2 flex items-center justify-center transition-colors cursor-pointer ${
                                                    isAllSelected 
                                                        ? 'bg-emerald-500 border-emerald-500' 
                                                        : isSomeSelected
                                                            ? 'bg-emerald-500 border-emerald-500'
                                                            : 'border-zinc-300 dark:border-zinc-600 hover:border-emerald-400'
                                                }`}
                                            >
                                                {isAllSelected && <Check size={14} strokeWidth={3} className="text-white" />}
                                                {isSomeSelected && !isAllSelected && <Minus size={14} strokeWidth={3} className="text-white" />}
                                            </div>
                                        </div>

                                        <div className="flex-1 min-w-0">
                                            <div className="flex items-center gap-2">
                                                <h3 className="font-medium text-zinc-900 dark:text-white truncate">{group.name}</h3>
                                                <span className="text-xs text-zinc-400 bg-zinc-100 dark:bg-zinc-800 px-1.5 py-0.5 rounded-full">{group.count}</span>
                                            </div>
                                            {group.domain && <p className="text-xs text-zinc-500 truncate">{group.domain}</p>}
                                        </div>
                                        <div className="text-zinc-400">
                                            {expandedGroups.has(group.id) ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                                        </div>
                                    </div>

                                    {/* Expanded Items */}
                                    {expandedGroups.has(group.id) && (
                                        <div className="border-t border-zinc-100 dark:border-zinc-800 bg-white dark:bg-zinc-950/50 overflow-visible">
                                            {group.senders.map(sender => (
                                                <div key={sender.email + sender.senderName} className="p-3 pl-11 flex items-center gap-3 hover:bg-zinc-50 dark:hover:bg-zinc-900/50 transition-colors border-b border-zinc-50 dark:border-zinc-800/50 last:border-0 overflow-visible relative">
                                                    <div 
                                                        onClick={() => {
                                                            sender.ids.forEach(id => toggleSelection(id));
                                                        }}
                                                        className={`w-4 h-4 rounded border-2 flex items-center justify-center transition-colors cursor-pointer flex-shrink-0 ${
                                                            sender.ids.every(id => selectedItems.has(id))
                                                                ? 'bg-emerald-500 border-emerald-500' 
                                                                : 'border-zinc-300 dark:border-zinc-600 hover:border-emerald-400'
                                                        }`}
                                                    >
                                                        {sender.ids.every(id => selectedItems.has(id)) && <Check size={12} strokeWidth={3} className="text-white" />}
                                                    </div>
                                                    <div className="flex-1 min-w-0">
                                                        <div className="text-sm font-medium text-zinc-900 dark:text-white truncate">{sender.senderName}</div>
                                                        <div className="text-xs text-zinc-500 truncate">{sender.email}</div>
                                                    </div>
                                                    <div className="text-xs text-zinc-400 flex-shrink-0">
                                                        {new Date(history.find(h => h.id === sender.ids[0])?.unsubscribed_at).toLocaleDateString()}
                                                    </div>
                                                    
                                                    {/* Action Menu */}
                                                    <div className="relative ml-auto flex-shrink-0">
                                                        <button
                                                            onClick={(e) => {
                                                                e.stopPropagation();
                                                                setActiveActionMenu(activeActionMenu === `history-${sender.email}` ? null : `history-${sender.email}`);
                                                            }}
                                                            className="p-1.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-300 transition-colors"
                                                        >
                                                            <MoreHorizontal size={14} />
                                                        </button>

                                                        {activeActionMenu === `history-${sender.email}` && (
                                                            <div className="absolute right-0 top-full mt-1 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg shadow-xl z-[9999] p-1 min-w-[180px]">
                                                                <button
                                                                    onClick={(e) => {
                                                                        e.stopPropagation();
                                                                        if (sender.originalItem?.id) removeFromHistory(sender.originalItem.id);
                                                                        sender.ids.forEach(id => removeFromHistory(id));
                                                                        setActiveActionMenu(null);
                                                                    }}
                                                                    className="w-full px-3 py-2 text-left text-sm hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors flex items-center gap-2 rounded-md"
                                                                >
                                                                    <RotateCcw size={14} />
                                                                    <span>Restore to Scan</span>
                                                                </button>
                                                                <button
                                                                    onClick={async (e) => {
                                                                        e.stopPropagation();
                                                                        const token = await getToken('gmail');
                                                                        if (!token) {
                                                                            addToast("Please connect Gmail API first", "error");
                                                                            return;
                                                                        }
                                                                        // Delete from inbox (trash)
                                                                        try {
                                                                            await GmailService.trashEmailsFrom(token.access_token, sender.email);
                                                                            addToast(`Deleted emails from ${sender.senderName}`, "success");
                                                                        } catch (error) {
                                                                            addToast("Failed to delete emails", "error");
                                                                        }
                                                                        setActiveActionMenu(null);
                                                                    }}
                                                                    className="w-full px-3 py-2 text-left text-sm hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors flex items-center gap-2 text-red-600 dark:text-red-400 rounded-md"
                                                                >
                                                                    <Trash2 size={14} />
                                                                    <span>Delete from Inbox</span>
                                                                </button>
                                                            </div>
                                                        )}
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                )}
            </div>

            {/* Floating Action Bar */}
            {selectedItems.size > 0 && (
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 px-4 py-2 rounded-full shadow-lg flex items-center gap-3 animate-in slide-in-from-bottom-4 duration-200 z-50">
                    <div className="text-sm font-medium">
                        {selectedItems.size} selected
                    </div>
                    <div className="flex items-center gap-2">
                        <button 
                            onClick={() => handleBulkAction('delete')}
                            className="p-2 hover:bg-white/10 dark:hover:bg-zinc-200/50 rounded-lg transition-colors text-red-400 dark:text-red-600"
                            title="Delete from History"
                        >
                            <Trash2 size={16} />
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

// API Provider Toggle component
const APIProviderToggle = ({ provider, label, isPremium, addToast }) => {
    const [isConnected, setIsConnected] = useState(false);
    const [isAuthenticating, setIsAuthenticating] = useState(false);

    useEffect(() => {
        const checkConnection = async () => {
            const connected = await isProviderConnected(provider);
            setIsConnected(connected);
        };
        checkConnection();
    }, [provider]);

    const handleToggle = async () => {
        if (isConnected) {
            // Disconnect
            await disconnectProvider(provider);
            setIsConnected(false);
            addToast(`${label} disconnected`, 'info');
        } else {
            // Connect - trigger OAuth via background script
            setIsAuthenticating(true);
            try {
                // Send message to background script to handle OAuth
                chrome.runtime.sendMessage(
                    { action: 'OAUTH_REQUEST', provider },
                    (response) => {
                        if (chrome.runtime.lastError) {
                            console.error('Runtime error:', chrome.runtime.lastError);
                            addToast(`Connection failed: ${chrome.runtime.lastError.message}`, 'error');
                            setIsAuthenticating(false);
                            return;
                        }
                        
                        if (response && response.error) {
                            console.error('OAuth failed:', response.error);
                            addToast(`Failed to connect ${label}: ${response.error}`, 'error');
                        } else if (response && response.success) {
                            console.log(`OAuth success for ${provider}`);
                            setIsConnected(true);
                            addToast(`${label} connected successfully!`, 'success');
                        }
                        setIsAuthenticating(false);
                    }
                );
            } catch (error) {
                console.error('OAuth failed:', error);
                addToast(`Failed to connect ${label}: ${error.message}`, 'error');
                setIsAuthenticating(false);
            }
        }
    };

    const isPremiumRequired = provider !== 'gmail';
    const isLocked = isPremiumRequired && !isPremium;

    return (
        <div
            onClick={() => {
                if (isLocked) {
                    addToast('Outlook API requires Premium. Upgrade to unlock!', 'error');
                } else if (!isAuthenticating) {
                    handleToggle();
                }
            }}
            className={`flex justify-between items-center p-3 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 cursor-pointer hover:bg-gray-50 dark:hover:bg-zinc-800 transition-colors ${isLocked ? 'opacity-60' : ''} ${isAuthenticating ? 'opacity-50 cursor-wait' : ''}`}
        >
            <div className="flex items-center gap-2">
                <span className="font-medium text-sm text-zinc-900 dark:text-white">{label}</span>
                {isConnected && (
                    <span className="px-1.5 py-0.5 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 text-[9px] font-bold uppercase tracking-wider rounded-sm">
                        API ✓
                    </span>
                )}
                {isPremiumRequired && (
                    <span className="px-1.5 py-0.5 bg-violet-100 dark:bg-violet-900/30 text-violet-700 dark:text-violet-400 text-[9px] font-bold uppercase tracking-wider rounded-sm border border-violet-200 dark:border-violet-900/50 flex items-center gap-1">
                        {isLocked && <Lock size={8} />} PREMIUM
                    </span>
                )}
            </div>
            <div className={`w-9 h-5 rounded-full relative transition-colors ${isConnected ? 'bg-emerald-500' : 'bg-zinc-200 dark:bg-zinc-700'}`}>
                <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow-sm transition-all duration-200 ${isConnected ? 'translate-x-4' : 'translate-x-0'} left-0.5`} />
            </div>
        </div>
    );
};

const SettingsView = ({ onClose, lang, setLang, t, setView, onDeleteSuccess, addToast }) => {
    const { user, isPremium, refreshProfile } = useAuth();

    // Persist enabled providers
    const [enabledProviders, setEnabledProviders] = useState(() => {
        try {
            return JSON.parse(localStorage.getItem('inbox-cleaner-providers')) || { 'Gmail': true, 'Outlook': false, 'Yahoo': false };
        } catch {
            return { 'Gmail': true, 'Outlook': false, 'Yahoo': false };
        }
    });

    const toggleProvider = (provider) => {
        // Prevent toggling if it's a premium provider and user is not premium
        // (Optional: you can add this logic if desired, for now just fixing the toggle)
        const newState = { ...enabledProviders, [provider]: !enabledProviders[provider] };
        setEnabledProviders(newState);
        localStorage.setItem('inbox-cleaner-providers', JSON.stringify(newState));
    };

    const languages = [
        { code: 'en', flag: '🇺🇸', name: 'English' },
        { code: 'es', flag: '🇪🇸', name: 'Español' },
        { code: 'hu', flag: '🇭🇺', name: 'Magyar' },
        { code: 'ja', flag: '🇯🇵', name: '日本語' },
        { code: 'zh', flag: '🇨🇳', name: '中文' }
    ];

    return (
        <div className="bg-white dark:bg-zinc-950 flex flex-col p-6 animate-in slide-in-from-right duration-300 overflow-y-auto min-h-[400px]">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold tracking-tight text-zinc-900 dark:text-white">{t.settings}</h2>
                <button onClick={onClose} className="hover:bg-gray-100 dark:hover:bg-zinc-800 p-1 rounded-full transition-colors text-zinc-900 dark:text-white"><X size={20} /></button>
            </div>

            <div className="flex flex-col gap-6">
                {/* Account Card */}
                <div className="p-4 rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50/50 dark:bg-zinc-900/50">
                    <div className="flex items-center gap-3 mb-6 p-3 bg-gray-50 dark:bg-zinc-800/50 rounded-xl border border-gray-100 dark:border-zinc-800">
                    <div className="w-10 h-10 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center text-emerald-600 dark:text-emerald-400 flex-shrink-0">
                        <User size={20} />
                    </div>
                    <div className="flex-1 min-w-0">
                        <div className="font-bold text-zinc-900 dark:text-white truncate">{user?.user_metadata?.full_name || user?.email}</div>
                        <div className="text-xs text-zinc-500 dark:text-zinc-400 truncate">{user?.email}</div>
                    </div>
                    {isPremium && (
                        <div className="px-1.5 py-0.5 bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 text-[9px] font-bold rounded-sm">
                            PRO
                        </div>
                    )}
                </div>
                    <button onClick={() => setView('subscription')} className="w-full py-2 bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-lg text-xs font-medium hover:bg-zinc-50 dark:hover:bg-zinc-700 transition-colors flex items-center justify-center gap-2 text-zinc-900 dark:text-white">
                        {isPremium ? <CreditCard size={14} /> : <Zap size={14} />}
                        {isPremium ? t.manageSub : t.upgrade}
                    </button>
                </div>

                {/* Language Dropdown */}
                <div>
                    <h3 className="text-xs font-bold opacity-50 uppercase tracking-wider mb-2 ml-1 text-zinc-900 dark:text-white">{t.language}</h3>
                    <div className="relative">
                        <select
                            value={lang}
                            onChange={(e) => setLang(e.target.value)}
                            className="w-full p-3 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 appearance-none cursor-pointer hover:border-emerald-500 transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-500/20 text-zinc-900 dark:text-white"
                        >
                            {languages.map(l => (
                                <option key={l.code} value={l.code}>{l.flag} {l.name}</option>
                            ))}
                        </select>
                        <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none opacity-50 text-zinc-900 dark:text-white">
                            <ChevronDown size={16} />
                        </div>
                    </div>
                </div>

                {/* API Provider Connections */}
                <div>
                    <div className="flex items-center justify-between mb-2 ml-1">
                        <h3 className="text-xs font-bold opacity-50 uppercase tracking-wider text-zinc-900 dark:text-white">{t.apiConnections || 'API Connections'}</h3>
                        <button 
                            onClick={() => window.location.reload()} 
                            className="text-xs text-emerald-600 dark:text-emerald-400 hover:underline"
                        >
                            Refresh
                        </button>
                    </div>
                    <div className="space-y-2">
                        <APIProviderToggle provider="gmail" label="Gmail" isPremium={isPremium} addToast={addToast} />
                        <APIProviderToggle provider="outlook" label="Outlook" isPremium={isPremium} addToast={addToast} />
                    </div>
                    <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-2 ml-1 leading-relaxed">
                        <ShieldAlert size={12} className="inline mr-1 relative -top-[1px]" />
                        Connect securely via the official Gmail API. Your data stays on your device. We use read-only access solely to scan for newsletters.
                    </p>
                </div>

                {/* Basic Provider Toggles (Yahoo only - DOM mode) */}
                <div>
                    <h3 className="text-xs font-bold opacity-50 uppercase tracking-wider mb-2 ml-1 text-zinc-900 dark:text-white">{t.providers || 'DOM Providers'}</h3>
                    <div className="space-y-2">
                        {['Yahoo'].map(provider => {
                            return (
                                <div
                                    key={provider}
                                    onClick={() => toggleProvider(provider)}
                                    className="flex justify-between items-center p-3 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 cursor-pointer hover:bg-gray-50 dark:hover:bg-zinc-800 transition-colors"
                                >
                                    <div className="flex items-center gap-2">
                                        <span className="font-medium text-sm text-zinc-900 dark:text-white">{provider}</span>
                                        <span className="px-1.5 py-0.5 bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 text-[9px] font-bold uppercase tracking-wider rounded-sm">
                                            Basic Mode
                                        </span>
                                    </div>
                                    <div className={`w-9 h-5 rounded-full relative transition-colors ${enabledProviders[provider] ? 'bg-emerald-500' : 'bg-zinc-200 dark:bg-zinc-700'}`}>
                                        <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow-sm transition-all duration-200 ${enabledProviders[provider] ? 'translate-x-4' : 'translate-x-0'} left-0.5`} />
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>

                {/* Help Section */}
                <div>
                    <h3 className="text-xs font-bold opacity-50 uppercase tracking-wider mb-2 ml-1 text-zinc-900 dark:text-white">{t.support}</h3>
                    <button 
                        onClick={() => setView('help')}
                        className="w-full flex justify-between items-center p-3 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 cursor-pointer hover:bg-gray-50 dark:hover:bg-zinc-800 transition-colors text-zinc-900 dark:text-white"
                    >
                        <div className="flex items-center gap-3">
                            <HelpCircle size={18} className="opacity-60" />
                            <span className="font-medium text-sm">{t.faqBtn}</span>
                        </div>
                        <ChevronDown size={16} className="-rotate-90 opacity-40" />
                    </button>
                </div>

                {/* Danger Zone */}
                <div>
                    <h3 className="text-xs font-bold opacity-50 uppercase tracking-wider mb-2 ml-1 text-red-500">{t.dangerZone}</h3>
                    <DeleteAccountButton onSuccess={onDeleteSuccess} t={t} />
                </div>


            </div>
        </div>
    );
};


// --- Bug Report View ---

const BugReportView = ({ onClose, t, setToast }) => {
    const { submitBugReport } = useAuth();
    const [type, setType] = useState('bug');
    const [description, setDescription] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);

        try {
            await submitBugReport(type, description, {
                userAgent: navigator.userAgent,
                platform: navigator.platform,
                language: navigator.language,
                timestamp: new Date().toISOString()
            });
            setToast({ message: t.reportSent, type: 'success' });
            setTimeout(() => {
                setToast({ message: t.reportThanks, type: 'info' });
                onClose();
            }, 1500);
        } catch (error) {
            console.error("Failed to send report:", error);
            setToast({ message: t.reportFailed, type: 'error' });
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="bg-white dark:bg-zinc-950 flex flex-col p-6 animate-in slide-in-from-right duration-300 h-full w-full min-h-[400px] rounded-2xl">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold tracking-tight text-zinc-900 dark:text-white">{t.reportBug}</h2>
                <button onClick={onClose} className="p-2 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-full transition-colors text-zinc-500 dark:text-zinc-400">
                    <X size={20} />
                </button>
            </div>

            <form onSubmit={handleSubmit} className="flex-1 flex flex-col gap-4 overflow-y-auto">
                <div>
                    <label className="text-xs font-bold uppercase opacity-50 mb-2 block">{t.issueType}</label>
                    <div className="relative">
                        <select
                            value={type}
                            onChange={(e) => setType(e.target.value)}
                            className="w-full p-3 rounded-xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 appearance-none cursor-pointer hover:border-emerald-500 transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-500/20 text-zinc-900 dark:text-white font-medium"
                        >
                            <option value="bug">{t.bugReport}</option>
                            <option value="feature">{t.featureRequest}</option>
                            <option value="other">{t.other}</option>
                        </select>
                        <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none opacity-50 text-zinc-900 dark:text-white">
                            <ChevronDown size={16} />
                        </div>
                    </div>
                </div>

                <div className="flex-1 flex flex-col">
                    <label className="text-xs font-bold uppercase opacity-50 mb-2 block">{t.description}</label>
                    <textarea
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        placeholder={t.describeIssue}
                        className="flex-1 w-full p-4 rounded-xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 resize-none min-h-[120px]"
                        required
                    />
                </div>

                <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-3 rounded-xl font-bold shadow-lg shadow-emerald-500/20 transition-all active:scale-95 disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                    {isSubmitting ? <RefreshCw size={18} className="animate-spin" /> : <><Send size={18} /> {t.submitReport}</>}
                </button>
            </form>
        </div>
    );
};


// --- Main App ---

const App = () => {
    const [isVisible, setIsVisible] = useState(true);
    const [isScanning, setIsScanning] = useState(false);
    const [results, setResults] = useState([]);
    const [rawResults, setRawResults] = useState([]);
    const [visibleLimit, setVisibleLimit] = useState(10); // For pagination
    const [selectedSenders, setSelectedSenders] = useState(new Set());
    const [expandedGroups, setExpandedGroups] = useState(new Set());
    const [trustedSenders, setTrustedSenders] = useState(new Set());
    const [activeActionMenu, setActiveActionMenu] = useState(null); // { id: string, x: number, y: number }
    const [stats, setStats] = useState({ newsletters: 0, clutterScore: 0 });

    // Enforce Dark Mode
    const [darkMode, setDarkMode] = useState(true);

    const [showProModal, setShowProModal] = useState(false);
    const [showDeleteSuccess, setShowDeleteSuccess] = useState(false);
    const [scanMode, setScanMode] = useState('quick');
    const [view, setView] = useState('home'); // 'home', 'settings', 'subscription', 'help'
    const [showProfileMenu, setShowProfileMenu] = useState(false);
    const [lang, setLang] = useState(() => localStorage.getItem('inbox-cleaner-lang') || 'en');
    const [toast, setToast] = useState(null);
    const [showWelcome, setShowWelcome] = useState(false);
    const [showGoodbye, setShowGoodbye] = useState(false);
    const [showLoginOverlay, setShowLoginOverlay] = useState(false);
    const [showOnboarding, setShowOnboarding] = useState(false);
    const [connectedProviders, setConnectedProviders] = useState([]);
    
    // Confirmation Modal State
    const [confirmation, setConfirmation] = useState({
        isOpen: false,
        title: '',
        message: '',
        onConfirm: () => {},
        isDangerous: false
    });

    // Bulk Selection State for Scan Results
    const [selectedScanItems, setSelectedScanItems] = useState(new Set());

    const appRef = useRef(null);
    const { user, isPremium, logout, upgradeToPremium, checkPremiumStatus, refreshProfile, addToHistory, addBatchToHistory, removeFromHistory, history, createPortalSession, cancelSubscription, resumeSubscription, markWelcomeAsSeen, markOnboardingAsSeen } = useAuth();

    const t = translations[lang] || translations['en'];

    const [showResumeSuccess, setShowResumeSuccess] = useState(false);

    const handleResume = async () => {
        try {
            await resumeSubscription();
            setShowResumeSuccess(true);
            setTimeout(() => setShowResumeSuccess(false), 3000);
        } catch (error) {
            setToast({ message: "Failed to resume subscription. Please try again.", type: 'error' });
        }
    };

    useEffect(() => {
        const handleToggle = () => setIsVisible(prev => !prev);
        window.addEventListener('inbox-cleaner-toggle', handleToggle);
        return () => window.removeEventListener('inbox-cleaner-toggle', handleToggle);
    }, []);

    // Trigger Onboarding
    useEffect(() => {
        console.log("[App] Checking onboarding trigger:", { 
            userExists: !!user, 
            hasMetadata: !!(user && user.user_metadata), 
            hasSeenOnboarding: user?.has_seen_onboarding 
        });

        if (user && user.user_metadata && !user.has_seen_onboarding) {
            console.log("[App] Triggering Onboarding Flow!");
            setShowOnboarding(true);
        }
    }, [user]);

    // Persist Dark Mode
    useEffect(() => {
        if (darkMode) {
            document.documentElement.classList.add('dark');
            localStorage.setItem('inbox-cleaner-theme', 'dark');
        } else {
            document.documentElement.classList.remove('dark');
            localStorage.setItem('inbox-cleaner-theme', 'light');
        }
    }, [darkMode]);

    const toggleTheme = () => setDarkMode(!darkMode);

    const addToast = (message, type = 'info') => {
        setToast({ message, type });
    };

    const [pendingAction, setPendingAction] = useState(null);

    useEffect(() => {
        if (user && pendingAction === 'unlock') {
            setShowProModal(true);
            setPendingAction(null);
        }
    }, [user, pendingAction]);

    const handleScan = async (mode) => {
        setScanMode(mode);
        if (mode === 'full' && !isPremium) {
            setShowProModal(true);
            return;
        }
        // Map 'full' UI mode to 'deep' scanner mode with 50 page limit
        startScan(mode === 'full' ? 50 : 1, mode === 'full' ? 'deep' : 'quick');
    };

    const startScan = async (maxPages, mode) => {
        setIsScanning(true);
        setShowProModal(false);
        setResults([]); // Clear previous results
        setVisibleLimit(10); // Reset pagination

        // Animation delay: Scale with load time
        const delay = mode === 'quick' ? 1500 : 3000;
        await new Promise(r => setTimeout(r, delay));

        try {
            const scanData = await scanInbox(maxPages, mode);

            if (scanData.error === 'LOCKED_PROVIDER') {
                addToast(`Cleaning ${scanData.provider} is a Premium Feature`, 'error');
                setShowProModal(true);
                return;
            }

            if (scanData.error === 'AUTH_REQUIRED') {
                setShowLoginOverlay(true);
                return;
            }

            if (scanData.error === 'CONTEXT_INVALID') {
                addToast("Extension updated. Please reload the page.", "error");
                return;
            }

            // Store RAW results
            setRawResults(scanData.results);
            
            // Initial filtering will happen via useEffect
            if (scanData.results.length === 0) {
                 addToast("No newsletters found", "info");
            }
        } catch (error) {
            console.error("Scan failed", error);
            addToast("Scan failed", "error");
        } finally {
            setIsScanning(false);
        }
    };

    // Dynamic Filtering: Re-run whenever history or rawResults changes
    useEffect(() => {
        if (rawResults.length === 0) {
            setResults([]);
            return;
        }

        // Handle both flat (old) and grouped (new) structures for backward compatibility/safety
        const filtered = rawResults.map(group => {
            // Check if group is trusted
            if (trustedSenders.has(group.id || group.email)) return null;

            // If it's a flat sender object (legacy/fallback), wrap it
            if (!group.senders) {
                const isUnsubscribed = history.some(h => 
                    (h.sender_email && h.sender_email === group.email) || 
                    (h.sender_name && h.sender_name === group.senderName)
                );
                return isUnsubscribed ? null : { ...group, senders: [group], count: group.count || 1 };
            }

            // Filter senders within the group
            const activeSenders = group.senders.filter(sender => {
                const isUnsubscribed = history.some(h => 
                    (h.sender_email && h.sender_email === sender.email) || 
                    (h.sender_name && h.sender_name === sender.senderName)
                );
                const isTrusted = trustedSenders.has(sender.email);
                return !isUnsubscribed && !isTrusted;
            });
            
            if (activeSenders.length === 0) return null;
            
            return {
                ...group,
                senders: activeSenders,
                count: activeSenders.reduce((sum, s) => sum + s.count, 0)
            };
        }).filter(Boolean);

        setResults(filtered);
        
        // Calculate total newsletters found
        const totalNewsletters = filtered.reduce((sum, g) => sum + g.senders.length, 0);

        setStats(prevStats => ({
            ...prevStats,
            newsletters: totalNewsletters,
            clutterScore: Math.min(100, totalNewsletters * 5)
        }));
    }, [rawResults, history, trustedSenders]);

    const [isProcessingPayment, setIsProcessingPayment] = useState(false);

    // Close modal and show success when premium status updates
    // Re-check premium status on window focus
    useEffect(() => {
        const handleFocus = () => {
            refreshProfile(); // Always refresh on focus to catch webhook updates
        };
        window.addEventListener('focus', handleFocus);
        return () => window.removeEventListener('focus', handleFocus);
    }, [refreshProfile]);

    useEffect(() => {
        if (isPremium && showProModal) {
            setShowProModal(false);
            // Only show welcome if not seen yet
            if (user && !user.has_seen_welcome) {
                setShowWelcome(true);
                markWelcomeAsSeen();
                setTimeout(() => setShowWelcome(false), 5000);
            }
            setIsProcessingPayment(false); // Reset processing state
        }
    }, [isPremium, showProModal, user]);

    const handleProUnlock = async () => {
        if (!user) {
            setPendingAction('unlock');
            setView('auth');
            return;
        }

        setIsProcessingPayment(true);
        try {
            await upgradeToPremium();
            // Modal stays open until realtime update closes it
        } catch (error) {
            console.error("Upgrade failed:", error);
            addToast("Failed to start checkout. Please try again.", "error");
            setIsProcessingPayment(false);
        }
    };

    const handleDeleteSuccess = () => {
        setShowDeleteSuccess(true);
        setTimeout(async () => {
            await logout();
            setShowDeleteSuccess(false);
            setView('home'); // Reset view
        }, 3000);
    };

    const handleLogout = () => {
        logout();
        setShowProfileMenu(false);
        addToast("Logged out successfully", "logout");
    };

    const toggleSender = (senderName) => {
        const newSelected = new Set(selectedSenders);
        if (newSelected.has(senderName)) {
            newSelected.delete(senderName);
        } else {
            newSelected.add(senderName);
        }
        setSelectedSenders(newSelected);
    };

    const toggleGroupSelection = (group) => {
        const newSelected = new Set(selectedSenders);
        const allSelected = group.senders.every(s => newSelected.has(s.senderName));
        
        group.senders.forEach(s => {
            if (allSelected) {
                newSelected.delete(s.senderName);
            } else {
                newSelected.add(s.senderName);
            }
        });
        setSelectedSenders(newSelected);
    };

    const toggleGroupExpand = (groupId) => {
        const newExpanded = new Set(expandedGroups);
        if (newExpanded.has(groupId)) {
            newExpanded.delete(groupId);
        } else {
            newExpanded.add(groupId);
        }
        setExpandedGroups(newExpanded);
    };

    const handleSelectAll = () => {
        const unlockLimit = isPremium ? Infinity : 3;
        const visibleResults = results.slice(0, unlockLimit);
        
        // Flatten visible senders
        const allVisibleSenders = visibleResults.flatMap(g => g.senders);
        
        const allSelected = allVisibleSenders.length > 0 && allVisibleSenders.every(s => selectedSenders.has(s.senderName));

        if (allSelected) {
            setSelectedSenders(new Set());
        } else {
            const newSelected = new Set();
            allVisibleSenders.forEach(s => newSelected.add(s.senderName));
            setSelectedSenders(newSelected);
        }
    };

    const [unsubscribeStats, setUnsubscribeStats] = useState({
        isVisible: false,
        total: 0,
        current: 0,
        successCount: 0,
        failCount: 0,
        currentSender: '',
        manualUnsubscribes: []
    });
    
    // Track manual unsubscribe actions separately for modal control
    const [manualUnsubscribes, setManualUnsubscribes] = useState([]);

    const scanRef = useRef({ isScanning: false, lastRun: 0 });

    // Bulk Selection Handlers
    const toggleScanSelection = (groupId) => {
        const newSelected = new Set(selectedScanItems);
        if (newSelected.has(groupId)) {
            newSelected.delete(groupId);
        } else {
            newSelected.add(groupId);
        }
        setSelectedScanItems(newSelected);
    };

    const clearScanSelection = () => {
        setSelectedScanItems(new Set());
    };

    const handleUnsubscribe = async () => {
        if (selectedScanItems.size === 0) return;
        
        // Reset manual unsubscribes state at start
        setManualUnsubscribes([]);
        
        // Use local variables for tracking during process
        let successCount = 0;
        let failCount = 0;
        let manualItems = [];
        
        try {
            // Get all selected groups
            const selectedGroups = results.filter(g => selectedScanItems.has(g.id));
            
            // Flatten to get all senders from selected groups
            const targets = selectedGroups.flatMap(g => g.senders);
            const total = targets.length;

            setUnsubscribeStats({
                isVisible: true,
                total: total,
                current: 0,
                successCount: 0,
                failCount: 0,
                currentSender: '',
                manualUnsubscribes: []
            });

            for (const sender of targets) {
                setUnsubscribeStats(prev => ({ ...prev, current: prev.current + 1, currentSender: sender.senderName }));
                try {
                    // Artificial delay for visual trust (as requested)
                    await new Promise(r => setTimeout(r, 800));

                    let result;
                    // Check if we can use API unsubscribe
                    if (sender.listUnsubscribe) {
                        result = await handleApiUnsubscribe(sender);
                    } 
                    
                    // Fallback to DOM if API failed or not available
                    if (!result || result.status === 'error') {
                         result = await unsubscribeFromSender(sender);
                    }

                    if (result.status === 'success') {
                        successCount++;
                        // Add to history
                        addBatchToHistory([{ senderName: sender.senderName, senderEmail: sender.email, method: 'unsubscribe' }]);
                        
                        // Show success feedback
                        addToast(`Unsubscribed from ${sender.senderName}`, 'success');
                    } else if (result.status === 'manual' || result.status === 'website_fallback') {
                        successCount++;
                        const manualItem = {
                            name: sender.senderName,
                            email: sender.email,
                            link: result.link,
                            type: result.type || result.status,
                            ids: sender.ids, // Pass message IDs for trashing
                            onTrash: async (item) => {
                                // Handle trash action
                                try {
                                    const token = await getToken('gmail');
                                    if (!token || !token.access_token) {
                                        addToast('Please reconnect Gmail to trash emails', 'error');
                                        return;
                                    }
                                    
                                    await GmailService.trashMessages(token.access_token, item.ids);
                                    addToast(`Moved ${item.name} to trash`, 'success');
                                    
                                    // Remove from manual list
                                    setManualUnsubscribes(prev => prev.filter(i => i.email !== item.email));
                                    
                                    // Add to history
                                    addBatchToHistory([{ senderName: item.name, senderEmail: item.email, method: 'trash' }]);
                                } catch (error) {
                                    console.error('[Trash] Failed:', error);
                                    addToast(`Failed to trash ${item.name}`, 'error');
                                }
                            }
                        };
                        manualItems.push(manualItem);
                        
                        // USER CONTROL: Don't auto-open links
                        // Let user click the button in the overlay to open
                        console.log('[Unsubscribe] Manual action required for:', sender.senderName, 'Type:', result.status);
                    } else {
                        failCount++;
                        console.error(`Unsubscribe failed for ${sender.senderName}:`, result.message || 'Unknown error');
                        addToast(`Failed to unsubscribe from ${sender.senderName}`, 'error');
                    }
                } catch (e) {
                    console.error("Unsubscribe failed for", sender.senderName, e);
                    failCount++;
                }

                setUnsubscribeStats(prev => ({
                    ...prev,
                    successCount,
                    failCount,
                    manualUnsubscribes: manualItems
                }));
                
                // Update React state for live UI updates
                setManualUnsubscribes(manualItems);
            }

            // Clear selection after completion
            clearScanSelection();
        } catch (error) {
            console.error('[Unsubscribe] Fatal error:', error);
            addToast('Unsubscribe process encountered an error', 'error');
        } finally {
            // CRITICAL: Only auto-close if there are NO manual actions
            // If manual actions exist, keep modal open until user clicks "Close"
            const hasManualActions = manualItems.length > 0;
            
            if (!hasManualActions) {
                setTimeout(() => {
                    setUnsubscribeStats(prev => ({ ...prev, isVisible: false }));
                }, 2000); // Show success results for 2 seconds
            }
            // If hasManualActions, modal stays open indefinitely
        }
    };

    const handleApiUnsubscribe = async (target) => {
        console.log('[Unsubscribe] Attempting API unsubscribe for:', target.email, 'Header:', target.listUnsubscribe);
        if (!target.listUnsubscribe) return { status: 'error', message: 'No List-Unsubscribe header' };

        // Parse List-Unsubscribe
        // Examples: 
        // <mailto:unsubscribe@example.com?subject=unsubscribe>
        // <https://example.com/unsubscribe>
        // <mailto:u@e.com>, <https://e.com/u>
        
        const links = target.listUnsubscribe.split(',').map(l => l.trim().replace(/^<|>$/g, ''));
        const httpsLink = links.find(l => l.startsWith('https://') || l.startsWith('http://'));
        const mailtoLink = links.find(l => l.startsWith('mailto:'));

        if (httpsLink) {
            console.log(`[Unsubscribe] Found HTTP link: ${httpsLink}`);
            
            // Add 10-second timeout to prevent hanging
            return Promise.race([
                new Promise(resolve => {
                    chrome.runtime.sendMessage({
                        action: 'UNSUBSCRIBE_VIA_POST',
                        url: httpsLink,
                        body: 'List-Unsubscribe=One-Click'
                    }, (response) => {
                        console.log('[Unsubscribe] POST response:', response);
                        if (response && response.success) resolve({ status: 'success', method: 'post' });
                        else {
                            // Fallback to GET
                             console.log('[Unsubscribe] POST failed, trying GET...');
                             chrome.runtime.sendMessage({
                                action: 'UNSUBSCRIBE_VIA_GET',
                                url: httpsLink
                            }, (resp) => {
                                 console.log('[Unsubscribe] GET response:', resp);
                                 if (resp && resp.success) resolve({ status: 'success', method: 'get' });
                                 else resolve({ status: 'error', message: resp?.error || 'Request failed' });
                            });
                        }
                    });
                }),
                // 10-second timeout
                new Promise(resolve => 
                    setTimeout(() => resolve({ status: 'error', message: 'Timeout after 10 seconds' }), 10000)
                )
            ]);
        } else if (mailtoLink) {
            console.log(`[Unsubscribe] Found MAILTO link: ${mailtoLink}`);
            // We can't easily send email via API without "compose" scope which we might not have?
            // We have 'gmail.modify'. We can insert a message into 'SENT' maybe?
            // Or just open the mailto link? Opening mailto opens a compose window, which is annoying.
            // Better to skip mailto for now or mark as manual.
            return { status: 'manual', link: mailtoLink };
        }

        return { status: 'error', message: 'No supported unsubscribe link' };
    };

    const handleTrustSender = (group) => {
        // Check if bulk mode is active
        const groupsToProcess = selectedScanItems.size > 0 
            ? results.filter(g => selectedScanItems.has(g.id))
            : [group];

        const newTrusted = new Set(trustedSenders);
        const allHistoryItems = [];

        for (const g of groupsToProcess) {
            newTrusted.add(g.id || g.email);
            
            // Add all senders in group to history
            const historyItems = g.senders.map(sender => ({
                senderName: sender.senderName,
                senderEmail: sender.email,
                method: 'trust'
            }));
            allHistoryItems.push(...historyItems);
        }

        setTrustedSenders(newTrusted);
        addBatchToHistory(allHistoryItems);
        
        const count = groupsToProcess.length;
        addToast(`Added ${count > 1 ? count + ' senders' : group.name} to Trusted Senders`, 'success');
        
        // Clear selection if bulk mode
        if (selectedScanItems.size > 0) {
            clearScanSelection();
        }
        
        setActiveActionMenu(null);
    };

    const handleReadLater = async (group) => {
        // Check if bulk mode is active
        const groupsToProcess = selectedScanItems.size > 0 
            ? results.filter(g => selectedScanItems.has(g.id))
            : [group];

        // This requires API access
        const token = await getToken('gmail');
        if (!token) {
            addToast("Please connect Gmail API first", "error");
            return;
        }

        addToast("Setting up Read Later...", "info");
        try {
            // Create Label (only once)
            const labelId = await GmailService.createLabel(token.access_token, "Inbox Cleaner / Read Later");
            
            const newTrusted = new Set(trustedSenders);
            const allHistoryItems = [];

            // Process each group
            for (const g of groupsToProcess) {
                // Create Filters for all senders in group
                for (const sender of g.senders) {
                    await GmailService.createFilter(token.access_token, sender.email, labelId);
                }
                
                // Add all senders to history
                const historyItems = g.senders.map(sender => ({
                    senderName: sender.senderName,
                    senderEmail: sender.email,
                    method: 'read_later'
                }));
                allHistoryItems.push(...historyItems);
                
                // Treat as "handled" - remove from view by adding to trusted
                newTrusted.add(g.id || g.email);
            }

            addBatchToHistory(allHistoryItems);
            setTrustedSenders(newTrusted);
            
            const count = groupsToProcess.length;
            addToast(`Moved ${count > 1 ? count + ' senders' : group.name} to Read Later`, "success");
            
            // Clear selection if bulk mode
            if (selectedScanItems.size > 0) {
                clearScanSelection();
            }
            
            setActiveActionMenu(null);
        } catch (e) {
            console.error(e);
            addToast("Failed to setup Read Later", "error");
        }
        setActiveActionMenu(null);
    };

    const handleKeepNewest = async (group) => {
        // Check if bulk mode is active
        const groupsToProcess = selectedScanItems.size > 0 
            ? results.filter(g => selectedScanItems.has(g.id))
            : [group];

        const token = await getToken('gmail');
        if (!token) {
            addToast("Please connect Gmail API first", "error");
            return;
        }

        setConfirmation({
            isOpen: true,
            title: 'Keep Newest Only?',
            message: `This will delete all emails from ${groupsToProcess.length > 1 ? groupsToProcess.length + ' senders' : group.name} except the most recent one. This action cannot be undone.`,
            confirmText: 'Clean Old Emails',
            isDangerous: true,
            onConfirm: async () => {
                addToast("Cleaning old emails...", "info");
                try {
                    let totalDeleted = 0;
                    const allHistoryItems = [];

                    for (const g of groupsToProcess) {
                        for (const sender of g.senders) {
                            const result = await GmailService.keepNewest(token.access_token, sender.email, 1);
                            totalDeleted += result.deleted;
                        }
                        
                        // Add all senders to history
                        const historyItems = g.senders.map(sender => ({
                            senderName: sender.senderName,
                            senderEmail: sender.email,
                            method: 'keep_newest'
                        }));
                        allHistoryItems.push(...historyItems);
                    }

                    addBatchToHistory(allHistoryItems);
                    addToast(`Cleaned ${totalDeleted} old emails`, "success");
                    
                    // Clear selection if bulk mode
                    if (selectedScanItems.size > 0) {
                        clearScanSelection();
                    }
                } catch (e) {
                    console.error(e);
                    addToast("Failed to clean old emails", "error");
                }
                setActiveActionMenu(null);
            }
        });
    };

    const handleLoadMore = () => {
        setVisibleLimit(prev => prev + 10);
    };


    const appendTo = () => appRef.current;

    const unlockLimit = isPremium ? Infinity : 3;

    // Auto-redirect to dashboard on login
    useEffect(() => {
        if (user && view === 'auth') {
            setView('home');
        }
    }, [user, view]);

    // Dynamic height for different views to prevent clipping
    // Removed fixed min-height to allow dynamic scaling
    // Added min-h during scanning to match results height
    const heightClass = `h-auto max-h-[90vh] flex flex-col ${(isScanning || showProModal || view === 'subscription' || view === 'help' || view === 'bug-report' || showLoginOverlay || unsubscribeStats.isVisible) ? 'min-h-[500px]' : ''}`;

    if (!isVisible) return null;

    return (
        <Draggable handle=".drag-handle">
            <div
                ref={appRef}
                className={`fixed top-4 right-4 w-80 rounded-2xl shadow-2xl border font-sans transition-all duration-300 ${darkMode ? 'bg-zinc-950 border-zinc-800 text-zinc-100' : 'bg-[#f8f9fa] border-gray-200 text-gray-800'} ${heightClass} ${showProfileMenu ? 'overflow-visible' : 'overflow-hidden'}`}
                style={{ zIndex: 2147483647 }}
            >
                {/* Toast - Positioned higher to avoid blocking bottom buttons */}
                {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

                {/* Scanning Overlay */}
                {isScanning && <ScanningOverlay mode={scanMode} isPremium={isPremium} t={t} />}

                {/* Unsubscribe Overlay */}
                <UnsubscribeOverlay 
                    isVisible={unsubscribeStats.isVisible}
                    total={unsubscribeStats.total}
                    current={unsubscribeStats.current}
                    successCount={unsubscribeStats.successCount}
                    failCount={unsubscribeStats.failCount}
                    currentSender={unsubscribeStats.currentSender}
                    manualUnsubscribes={manualUnsubscribes}
                    onClose={() => {
                        setUnsubscribeStats(prev => ({ ...prev, isVisible: false }));
                        setManualUnsubscribes([]);
                    }}
                />

                {/* Welcome Confetti */}
                {showWelcome && (
                    <div className="absolute inset-0 z-[70] flex flex-col items-center justify-center bg-white/90 dark:bg-zinc-950/90 backdrop-blur-sm animate-in fade-in duration-500">
                        <div className="absolute inset-0 pointer-events-none">
                            <Lottie animationData={confettiData} loop={false} />
                        </div>
                        <h2 className="text-2xl font-bold text-zinc-900 dark:text-white mb-2 relative z-10">
                            {user?.has_been_premium ? t.welcomeBackPremium : t.welcomePremium}
                        </h2>
                        <p className="text-zinc-600 dark:text-zinc-400 relative z-10">
                            {user?.has_been_premium ? t.premiumActive : t.enjoyPremium}
                        </p>
                    </div>
                )}

                {/* Goodbye Screen */}
                {showGoodbye && (
                    <div className="absolute inset-0 z-[70] flex flex-col items-center justify-center bg-white/90 dark:bg-zinc-950/90 backdrop-blur-sm animate-in fade-in duration-500">
                        <div className="w-24 h-24 mb-6 bg-zinc-100 dark:bg-zinc-800 rounded-full flex items-center justify-center text-zinc-400 dark:text-zinc-500">
                            <Trash2 size={48} />
                        </div>
                        <h2 className="text-2xl font-bold text-zinc-900 dark:text-white mb-2">{t.sadSeeYouGo}</h2>
                        <p className="text-zinc-600 dark:text-zinc-400">{t.subCancelledMsg}</p>
                    </div>
                )}

                {/* Login Required Overlay */}
                {showLoginOverlay && (
                    <div className="absolute inset-0 z-[70] flex flex-col items-center justify-center bg-white/90 dark:bg-zinc-950/90 backdrop-blur-sm animate-in fade-in duration-500">
                        <div className="w-24 h-24 mb-6 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center text-blue-600 dark:text-blue-400">
                            <Lock size={48} />
                        </div>
                        <h2 className="text-2xl font-bold text-zinc-900 dark:text-white mb-2">{t.accessRequired}</h2>
                        <p className="text-zinc-600 dark:text-zinc-400 text-center px-8 mb-6">
                            {t.reloginMsg}
                        </p>
                        <button 
                            onClick={async () => {
                                setShowLoginOverlay(false);
                                await logout();
                                setView('auth');
                            }}
                            className="bg-emerald-500 hover:bg-emerald-600 text-white px-6 py-3 rounded-xl font-bold transition-colors shadow-lg shadow-emerald-500/20"
                        >
                            {t.loginSignup}
                        </button>
                    </div>
                )}

                {/* Resume Success Screen */}
                {showResumeSuccess && (
                    <div className="absolute inset-0 z-[70] flex flex-col items-center justify-center bg-white/90 dark:bg-zinc-950/90 backdrop-blur-sm animate-in fade-in duration-500">
                        <div className="w-24 h-24 mb-6 bg-emerald-100 dark:bg-emerald-900/30 rounded-full flex items-center justify-center text-emerald-600 dark:text-emerald-400">
                            <Check size={48} />
                        </div>
                        <h2 className="text-2xl font-bold text-zinc-900 dark:text-white mb-2">{t.resumeSuccess}</h2>
                        <p className="text-zinc-600 dark:text-zinc-400">{t.resumeMsg}</p>
                    </div>
                )}

                {/* Views */}
                {/* Use relative positioning for all views so they expand the container */}
                {view === 'auth' && <div className="relative z-[60]"><AuthView onClose={() => setView('home')} t={t} /></div>}

                {view === 'settings' && (
                    <div className="relative z-[60]">
                        <SettingsView onClose={() => setView('home')} lang={lang} setLang={setLang} t={t} setView={setView} onDeleteSuccess={handleDeleteSuccess} addToast={addToast} />
                    </div>
                )}

                {/* Bug Report View */}
                {view === 'bug-report' && (
                    <div className="absolute inset-0 z-[60]">
                        <BugReportView 
                            onClose={() => setView('home')} 
                            t={t}
                        />
                    </div>
                )}

                {/* Help View */}
                {view === 'help' && (
                    <div className="absolute inset-0 z-[60]">
                        <HelpView 
                            onClose={() => setView('settings')} 
                            t={t}
                        />
                    </div>
                )}

                {/* History View */}
                {view === 'history' && (
                    <div className="relative z-[60]">
                        <HistoryView 
                            onClose={() => setView('home')} 
                            t={t} 
                            appRef={appRef}
                        />
                    </div>
                )}

                {showDeleteSuccess && <DeleteSuccessOverlay t={t} />}
                
                <ConfirmationModal 
                    isOpen={confirmation.isOpen}
                    onClose={() => setConfirmation(prev => ({ ...prev, isOpen: false }))}
                    {...confirmation}
                />     
                {view === 'subscription' && (
                    <div className="relative z-[60]">
                        <SubscriptionView
                            onClose={() => setView('settings')}
                            t={t}
                            addToast={addToast}
                            setToast={setToast}
                            onCancel={() => {
                                setShowGoodbye(true);
                                setTimeout(() => setShowGoodbye(false), 4000);
                            }}
                            onResume={() => {
                                setShowResumeSuccess(true);
                                setTimeout(() => setShowResumeSuccess(false), 3000);
                            }}
                            onUpgrade={() => {
                                // This will be handled by the useEffect watching isPremium
                                setShowProModal(true);
                            }}
                        />
                    </div>
                )}

                {/* Header */}
                {view === 'home' && (
                    <div className="p-4 flex justify-between items-center border-b border-gray-100 dark:border-zinc-800 bg-white/50 dark:bg-zinc-900/50 backdrop-blur-sm sticky top-0 z-10 rounded-t-2xl">
                        <div className="flex items-center gap-2">
                            <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center shadow-lg shadow-emerald-600/20 text-white">
                                <Mail size={18} strokeWidth={2.5} />
                            </div>
                            <div>
                                <h1 className="font-bold text-lg tracking-tight text-zinc-900 dark:text-white leading-none">Inbox Cleaner</h1>
                                <span className={`text-[10px] font-bold uppercase tracking-wider ${isPremium ? 'text-transparent bg-clip-text bg-gradient-to-r from-violet-400 to-fuchsia-400' : 'text-zinc-500'}`}>
                                    {isPremium ? t.premiumPlan : t.freePlanHeader}
                                </span>
                            </div>
                        </div>
                        <div className="flex gap-2">
                            <div>
                                <button onClick={() => setShowProfileMenu(!showProfileMenu)} className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/10 transition-colors">
                                    <User size={16} className="lucide lucide-rotate-ccw " />
                                </button>

                                {/* Profile Menu */}
                                {showProfileMenu && (
                                    <>
                                        {/* Transparent Overlay for Click Outside */}
                                        <div className="fixed inset-0 z-40" onClick={() => setShowProfileMenu(false)}></div>
                                        <div className="absolute top-[56px] right-[6px] w-56 bg-white dark:bg-zinc-900 rounded-xl shadow-xl border border-gray-100 dark:border-zinc-800 p-1 z-50 animate-in fade-in zoom-in-95 duration-200">
                                            {user ? (
                                                <>
                                                    <div className="px-3 py-2 mb-1 border-b border-gray-100 dark:border-zinc-800">
                                                        <p className="text-sm font-bold truncate text-zinc-900 dark:text-white">{user.user_metadata?.full_name || user.user_metadata?.name || user.email}</p>
                                                        <p className="text-xs opacity-60 truncate text-zinc-900 dark:text-white">{user.email}</p>
                                                    </div>
                                                    <button onClick={() => { setView('settings'); setShowProfileMenu(false); }} className="w-full text-left px-3 py-2 text-sm rounded-lg hover:bg-gray-50 dark:hover:bg-zinc-800 flex items-center gap-2 text-zinc-900 dark:text-white mb-1 transition-colors">
                                                        <Settings size={14} /> {t.settings}
                                                    </button>
                                                    <button onClick={() => { setView('bug-report'); setShowProfileMenu(false); }} className="w-full text-left px-3 py-2 text-sm rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 flex items-center gap-2 text-red-600/80 dark:text-red-400/80 font-medium mb-1 transition-colors">
                                                        <Bug size={14} className="text-red-500/80 dark:text-red-400/80" /> {t.reportBug}
                                                    </button>
                                                    <button onClick={() => { handleLogout(); }} className="w-full text-left px-3 py-2 text-sm rounded-lg hover:bg-gray-50 dark:hover:bg-zinc-800 text-red-500 flex items-center gap-2 transition-colors">
                                                        <LogOut size={14} /> {t.logout}
                                                    </button>
                                                </>
                                            ) : (
                                                <button onClick={() => { setView('auth'); setShowProfileMenu(false); }} className="w-full text-left px-3 py-2 text-sm rounded-lg hover:bg-gray-50 dark:hover:bg-zinc-800 font-bold text-emerald-500 transition-colors">
                                                    {t.login} / {t.signup}
                                                </button>
                                            )}
                                        </div>
                                    </>
                                )}
                            </div>

                            {/* History Button (Replaces Theme Toggle) */}
                            {isPremium && (
                                <button onClick={() => setView('history')} className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/10 transition-colors text-zinc-900 dark:text-white">
                                    <RotateCcw size={16} />
                                </button>
                            )}

                            <button onClick={() => setIsVisible(false)} className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/10 transition-colors text-zinc-900 dark:text-white">
                                <X size={16} />
                            </button>
                        </div>
                    </div>
                )}

                {/* Body - Only show if view is dashboard */}
                {view === 'home' && (
                    <div className={`p-4 flex flex-col gap-4 max-h-[80vh] overflow-y-auto custom-scrollbar relative ${results.length === 0 ? '' : ''}`}>

                        {/* Stats Cards */}
                        <div className="grid grid-cols-2 gap-3">
                            <div className={`p-4 rounded-xl text-center border ${darkMode ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-gray-100 shadow-sm'}`}>
                                <div className="text-2xl font-bold text-emerald-500">{stats.newsletters}</div>
                                <div className="text-xs opacity-60 font-medium">{t.newsletters}</div>
                            </div>
                            <div className={`p-4 rounded-xl text-center border ${darkMode ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-gray-100 shadow-sm'}`}>
                                <div className="flex justify-center items-center gap-1">
                                    <div className="text-2xl font-bold text-orange-500">{stats.clutterScore}</div>
                                </div>
                                <div className="text-xs opacity-60 font-medium flex justify-center items-center gap-1">
                                    {t.clutterScore}
                                    <Tippy content="Based on frequency and keywords." appendTo={appendTo} placement="top" zIndex={999999}>
                                        <div className="cursor-help inline-flex"><Info size={10} /></div>
                                    </Tippy>
                                </div>
                            </div>
                        </div>

                        {/* Scan Buttons */}
                        <div className="flex gap-2">
                            <Tippy content="Scans 1st page only." appendTo={appendTo} placement="top" zIndex={999999}>
                                <button
                                    onClick={() => handleScan('quick')}
                                    disabled={isScanning}
                                    className="flex-[1.2] bg-emerald-600 hover:bg-emerald-700 text-white py-3 rounded-xl font-semibold flex justify-center items-center gap-2 transition-all active:scale-95 disabled:opacity-70 shadow-lg shadow-emerald-500/20 overflow-hidden relative whitespace-normal h-auto min-h-[48px]"
                                >
                                    <RefreshCw size={18} className="flex-shrink-0" /> <span className="text-center leading-tight">{t.quickScan}</span>
                                </button>
                            </Tippy>

                            <Tippy content="Scans Entire Inbox (Pro)" appendTo={appendTo} placement="top" zIndex={999999}>
                                <button
                                    onClick={() => handleScan('full')}
                                    disabled={isScanning}
                                    className="flex-[1.2] bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white py-3 rounded-xl font-semibold flex justify-center items-center gap-2 transition-all active:scale-95 disabled:opacity-70 relative overflow-hidden group shadow-lg shadow-indigo-500/20"
                                >
                                    <Crown size={18} className="text-yellow-300" /> {t.deepScan}
                                </button>
                            </Tippy>
                        </div>

                        {/* List */}
                        {results.length > 0 && (
                            <div className="flex flex-col gap-3 animate-in fade-in slide-in-from-bottom-4 duration-500">
                                <div className="flex gap-2 items-center justify-between">
                                    <div className="text-sm font-semibold">{t.foundSenders.replace('{count}', results.length)}</div>
                                    <button 
                                        onClick={() => {
                                            const allGroupIds = results.slice(0, isPremium ? undefined : 3).map(g => g.id);
                                            const allSelected = allGroupIds.every(id => selectedScanItems.has(id));
                                            
                                            if (allSelected) {
                                                // Deselect all
                                                setSelectedScanItems(new Set());
                                            } else {
                                                // Select all
                                                setSelectedScanItems(new Set(allGroupIds));
                                            }
                                        }}
                                        className="text-xs text-emerald-500 dark:text-emerald-400 hover:underline font-medium"
                                    >
                                        {(results.length > 0 && results.slice(0, isPremium ? undefined : 3).every(g => selectedScanItems.has(g.id))) ? t.deselectAll : t.selectAll}
                                    </button>
                                </div>

                                <div className="flex flex-col gap-2 max-h-60 overflow-y-auto pr-1">
                                    {results.slice(0, visibleLimit).map((group, idx) => {
                                        // Debug logging
                                        if (idx < 5) console.log(`Rendering group ${idx}:`, JSON.stringify(group));
                                        
                                        const isLocked = idx >= unlockLimit;
                                        const groupId = group.id || group.email;
                                        const isExpanded = expandedGroups.has(groupId);
                                        const groupSelectedCount = group.senders.filter(s => selectedSenders.has(s.senderName)).length;
                                        const isAllSelected = groupSelectedCount === group.senders.length && group.senders.length > 0;
                                        const isPartialSelected = groupSelectedCount > 0 && !isAllSelected;

                                        return (
                                            <div key={groupId} className="flex flex-col gap-1">
                                                {/* Group Header */}
                                                <div
                                                    onClick={(e) => {
                                                        // Allow clicking anywhere on the header to select
                                                        if (!isLocked && !e.target.closest('.action-menu')) {
                                                            toggleScanSelection(groupId);
                                                        }
                                                    }}
                                                    className={`relative flex items-center gap-3 p-3 rounded-xl border transition-all cursor-pointer ${
                                                        isLocked
                                                            ? 'opacity-60 blur-[2px] select-none grayscale'
                                                            : `${darkMode ? 'bg-zinc-900/50 border-zinc-800 hover:bg-zinc-900' : 'bg-white border-gray-100 hover:bg-gray-50 shadow-sm'}`
                                                    }`}
                                                >
                                                    {isLocked && (
                                                        <div className="absolute inset-0 z-10 flex items-center justify-center">
                                                            <div className="bg-black/80 text-white p-1.5 rounded-full shadow-lg">
                                                                <Lock size={14} />
                                                            </div>
                                                        </div>
                                                    )}

                                                    {/* Bulk Selection Checkbox */}
                                                    <div 
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            e.preventDefault();
                                                            if (!isLocked) {
                                                                toggleScanSelection(groupId);
                                                            }
                                                        }}
                                                        className={`relative z-10 w-5 h-5 flex items-center justify-center rounded border-2 transition-colors cursor-pointer ${
                                                            selectedScanItems.has(groupId) 
                                                                ? 'bg-emerald-500 border-emerald-500' 
                                                                : 'border-gray-300 dark:border-zinc-600 hover:border-emerald-400'
                                                        }`}
                                                        style={{pointerEvents: 'auto'}}
                                                    >
                                                        {selectedScanItems.has(groupId) && <Check size={14} strokeWidth={3} className="text-white pointer-events-none" />}
                                                    </div>

                                                    {/* Expand Toggle */}
                                                    {group.senders.length > 1 ? (
                                                        <button 
                                                            onClick={(e) => {
                                                                e.stopPropagation();
                                                                toggleGroupExpand(groupId);
                                                            }}
                                                            className={`p-1 rounded-full hover:bg-black/5 dark:hover:bg-white/10 transition-transform ${isExpanded ? 'rotate-90' : ''}`}
                                                        >
                                                            <ChevronRight size={16} className="opacity-50" />
                                                        </button>
                                                    ) : (
                                                        <div className="w-6" /> // Spacer
                                                    )}

                                                    {/* Content */}
                                                    <div className="flex-1 min-w-0 flex items-center gap-2">
                                                        <div className="flex-1 min-w-0">
                                                            <div className="font-semibold text-sm truncate">{group.name}</div>
                                                            {group.domain && <div className="text-xs opacity-50 truncate">{group.domain}</div>}
                                                        </div>
                                                        <div className={`text-xs font-bold px-2 py-1 rounded-full ${darkMode ? 'bg-zinc-800 text-zinc-300' : 'bg-gray-100 text-gray-600'}`}>
                                                            {group.count}
                                                        </div>
                                                    </div>

                                                    {/* More Actions Menu Button */}
                                                    {!isLocked && (
                                                        <div className="relative action-menu">
                                                            <button 
                                                                onClick={(e) => {
                                                                    e.stopPropagation();
                                                                    setActiveActionMenu(activeActionMenu?.id === groupId ? null : { id: groupId });
                                                                }}
                                                                className="p-1.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/10 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 transition-colors"
                                                            >
                                                                <MoreHorizontal size={16} />
                                                            </button>
                                                            
                                                            {/* Dropdown Menu */}
                                                            {activeActionMenu?.id === groupId && (
                                                                <>
                                                                    <div className="fixed inset-0 z-40" onClick={(e) => { e.stopPropagation(); setActiveActionMenu(null); }} />
                                                                    <div className="absolute right-0 top-8 z-50 w-48 bg-white dark:bg-zinc-900 rounded-xl shadow-xl border border-gray-100 dark:border-zinc-800 p-1 animate-in fade-in zoom-in-95 duration-200">
                                                                        <button onClick={(e) => { e.stopPropagation(); handleReadLater(group); }} className="w-full text-left px-3 py-2 text-sm rounded-lg hover:bg-gray-50 dark:hover:bg-zinc-800 flex items-center gap-2 text-zinc-900 dark:text-white transition-colors">
                                                                            <Clock size={14} className="text-blue-500" /> {t.readLater || "Read Later"}
                                                                        </button>
                                                                        <button onClick={(e) => { e.stopPropagation(); handleKeepNewest(group); }} className="w-full text-left px-3 py-2 text-sm rounded-lg hover:bg-gray-50 dark:hover:bg-zinc-800 flex items-center gap-2 text-zinc-900 dark:text-white transition-colors">
                                                                            <Archive size={14} className="text-orange-500" /> {t.keepNewest || "Keep Newest"}
                                                                        </button>
                                                                        <div className="h-px bg-gray-100 dark:bg-zinc-800 my-1" />
                                                                        <button onClick={(e) => { e.stopPropagation(); handleTrustSender(group); }} className="w-full text-left px-3 py-2 text-sm rounded-lg hover:bg-gray-50 dark:hover:bg-zinc-800 flex items-center gap-2 text-zinc-900 dark:text-white transition-colors">
                                                                            <ShieldCheck size={14} className="text-emerald-500" /> {t.trustSender || "Trust Sender"}
                                                                        </button>
                                                                    </div>
                                                                </>
                                                            )}
                                                        </div>
                                                    )}
                                                </div>

                                                {/* Expanded Senders */}
                                                {isExpanded && !isLocked && (
                                                    <div className="pl-11 pr-2 flex flex-col gap-2 animate-in slide-in-from-top-2 duration-200">
                                                        {group.senders.map((sender, sIdx) => (
                                                            <div 
                                                                key={`${groupId}-${sIdx}`}
                                                                onClick={() => toggleSender(sender.senderName)}
                                                                className="flex items-center gap-3 p-2 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 cursor-pointer text-sm"
                                                            >
                                                                <div className={`w-4 h-4 flex items-center justify-center rounded border ${selectedSenders.has(sender.senderName) ? 'bg-emerald-500 border-emerald-500' : 'border-gray-300 dark:border-zinc-600'} transition-colors`}>
                                                                    {selectedSenders.has(sender.senderName) && <Check size={10} className="text-white" />}
                                                                </div>
                                                                <div className="flex-1 min-w-0">
                                                                    <div className="font-medium truncate">{sender.senderName}</div>
                                                                    <div className="text-xs opacity-50 truncate">{sender.email}</div>
                                                                </div>
                                                                <div className="text-xs opacity-50">{sender.count}</div>
                                                            </div>
                                                        ))}
                                                    </div>
                                                )}
                                            </div>
                                        );
                                    })}

                                    {/* Locked Rows (Sneak Peek) */}
                                    {!isPremium && scanMode === 'quick' && (
                                        <>
                                            {Array.from({ length: 5 }).map((_, i) => (
                                                <div
                                                    key={`locked-${i}`}
                                                    onClick={() => setShowProModal(true)}
                                                    className="relative flex items-center gap-3 p-3 rounded-xl border transition-all cursor-pointer opacity-60 blur-[2px] select-none grayscale bg-gray-50 border-gray-100 dark:bg-zinc-900/30 dark:border-zinc-800"
                                                >
                                                    <div className="absolute inset-0 z-10 flex items-center justify-center">
                                                        <div className="bg-zinc-900/80 dark:bg-black/80 text-white p-1.5 rounded-full shadow-lg backdrop-blur-sm">
                                                            <Lock size={14} />
                                                        </div>
                                                    </div>

                                                    <div className="w-5 h-5 rounded border border-gray-300 dark:border-zinc-700"></div>

                                                    <div className="flex-1 min-w-0">
                                                        <div className="font-semibold text-sm truncate">
                                                            {['N*ws*ett*r', 'M*rk*t*ng', 'Upd*t*s', 'W**kly D*g*st', 'Sp*c**l Off*r'][i % 5]}
                                                        </div>
                                                        <div className="text-xs opacity-50 truncate">
                                                            {['n*ws@ex*mpl*.c*m', 'h*llo@m*rk*t.n*t', 'inf*@d*ily.c*m', 't*am@s*rv*c*.io', 'n*r*ply@*l*rt.org'][i % 5]}
                                                        </div>
                                                    </div>
                                                    <div className="text-xs font-bold px-2 py-1 rounded-full bg-gray-100 dark:bg-zinc-800 text-gray-400 dark:text-zinc-600">
                                                        {Math.floor(Math.random() * 20) + 5}
                                                    </div>
                                                </div>
                                            ))}
                                            
                                            <div className="text-center p-4">
                                                <div className="p-4 bg-gradient-to-r from-violet-500/10 to-fuchsia-500/10 rounded-xl border border-violet-500/20 mb-6">
                    <div className="flex items-center justify-between mb-2">
                        <h3 className="font-bold text-zinc-900 dark:text-white flex items-center gap-2">
                            <Crown size={18} className="text-violet-500" />
                            {t.premiumPlan}
                        </h3>
                        <span className="px-2 py-1 bg-violet-500 text-white text-xs font-bold rounded-full">PRO</span>
                    </div>
                    <p className="text-sm opacity-70 mb-3">{t.unlockDesc}</p>
                    <button 
                        onClick={() => setShowProModal(true)}
                        className="w-full py-2 bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 text-white rounded-lg font-bold text-sm shadow-lg shadow-violet-500/20 transition-all active:scale-95"
                    >
                        {t.upgradeToPro}
                    </button>
                </div>
                                            </div>
                                        </>
                                    )}

                                    {/* Load More Button - Only show if NOT in quick mode (since quick mode shows all 50 + locked) */}
                                    {visibleLimit < results.length && scanMode !== 'quick' && (
                                        <button
                                            onClick={handleLoadMore}
                                            className="w-full py-2 text-xs font-medium text-emerald-500 hover:bg-emerald-50 dark:hover:bg-emerald-900/10 rounded-lg transition-colors whitespace-normal h-auto"
                                        >
                                            {t.loadMore.replace('{count}', results.length - visibleLimit)}
                                        </button>
                                    )}

                                    {/* Upsell Message (Hidden for Quick Mode since we have the locked rows now) */}
                                    {/* Premium Warning for Quick Scan */}
                                    {scanMode === 'quick' && isPremium && (
                                        <div className="text-center p-2 text-xs opacity-60">
                                            <Info size={12} className="inline mr-1 flex-shrink-0" />
                                            {t.quickScanInfo}
                                        </div>
                                    )}
                                </div>

                                <button
                                    onClick={handleUnsubscribe}
                                    disabled={selectedScanItems.size === 0}
                                    className="w-full bg-red-500 hover:bg-red-600 text-white py-3 rounded-xl font-semibold flex justify-center items-center gap-2 transition-all active:scale-95 disabled:opacity-50 shadow-lg shadow-red-500/20 mt-2 overflow-hidden relative whitespace-normal h-auto min-h-[48px]"
                                >
                                    <Trash2 size={18} className="flex-shrink-0" /> <span className="text-center leading-tight">{t.unsubscribe.replace('{count}', selectedScanItems.size)}</span>
                                </button>
                            </div>
                        )}
                    </div>
                )}

                {/* Premium Modal */}
                {showProModal && (
                    <div className="absolute inset-2 z-50 flex items-center justify-center animate-in fade-in duration-200">
                        <div className="absolute inset-0 bg-black/60 backdrop-blur-sm rounded-xl" onClick={() => setShowProModal(false)}></div>
                        <div className={`relative w-full max-h-full overflow-y-auto p-6 rounded-xl shadow-2xl flex flex-col justify-center ${darkMode ? 'bg-zinc-950 border border-zinc-800' : 'bg-white'}`}>
                            <button onClick={() => setShowProModal(false)} className="absolute top-4 right-4 opacity-50 hover:opacity-100"><X size={20} /></button>
                            <div className="flex justify-center mb-4">
                                <div className="p-3 bg-violet-400/20 rounded-full text-violet-500"><Crown size={32} className="animate-pulse" /></div>
                            </div>
                            <h2 className="text-xl font-bold mb-2 text-center">{t.unlockDeepScan}</h2>
                            <p className="text-sm opacity-70 mb-6 leading-relaxed text-center">{t.unlockDesc}</p>
                            <div className="space-y-3 mb-6 px-2">
                                <div className="flex items-center gap-2 text-sm"><Check size={16} className="text-emerald-500" /><span>{t.unlimitedPageScanning}</span></div>
                                <div className="flex items-center gap-2 text-sm"><Check size={16} className="text-emerald-500" /><span>{t.oneClickUnsubscribe}</span></div>
                                <div className="flex items-center gap-2 text-sm"><Check size={16} className="text-emerald-500" /><span>{t.prioritySupport}</span></div>
                            </div>
                            <button
                                onClick={handleProUnlock}
                                disabled={isProcessingPayment}
                                className="w-full bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 text-white py-3 rounded-xl font-bold shadow-lg shadow-fuchsia-500/20 transition-all active:scale-95 relative overflow-hidden group disabled:opacity-70 disabled:cursor-not-allowed"
                            >
                                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
                                {isProcessingPayment ? (
                                    <div className="flex items-center justify-center gap-2">
                                        <RefreshCw size={18} className="animate-spin" />
                                        <span>Processing...</span>
                                    </div>
                                ) : (
                                    t.unlockBtn
                                )}
                            </button>
                            <p className="text-[10px] text-center mt-3 opacity-50">Cancel anytime. Secure payment via Stripe.</p>
                        </div>
                    </div>
                )}
            </div>
        </Draggable>
    );
};

const DeleteAccountButton = ({ onSuccess, t }) => {
    const { deleteAccount } = useAuth();
    const [isConfirming, setIsConfirming] = useState(false);
    const [isDeleting, setIsDeleting] = useState(false);

    const handleDelete = async () => {
        setIsDeleting(true);
        try {
            await deleteAccount();
            if (onSuccess) onSuccess();
        } catch (error) {
            console.error("Delete failed:", error);
            alert("Failed to delete account. Please try again.");
            setIsDeleting(false);
        }
    };

    if (isConfirming) {
        return (
            <div className="p-4 rounded-xl border border-red-200 bg-red-50 dark:bg-red-900/10 dark:border-red-900/30 animate-in fade-in zoom-in-95 duration-200">
                <h4 className="font-bold text-red-600 dark:text-red-400 mb-1 text-sm">{t.areYouSure}</h4>
                <p className="text-xs text-red-600/80 dark:text-red-400/80 mb-3">
                    {t.deleteWarning}
                </p>
                <div className="flex gap-2">
                    <button 
                        onClick={handleDelete}
                        disabled={isDeleting}
                        className="flex-1 bg-red-600 hover:bg-red-700 text-white py-2 rounded-lg text-xs font-bold transition-colors disabled:opacity-50"
                    >
                        {isDeleting ? "Deleting..." : t.yesDelete}
                    </button>
                    <button 
                        onClick={() => setIsConfirming(false)}
                        disabled={isDeleting}
                        className="flex-1 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 text-zinc-600 dark:text-zinc-400 py-2 rounded-lg text-xs font-bold hover:bg-zinc-50 dark:hover:bg-zinc-800 transition-colors"
                    >
                        {t.cancel}
                    </button>
                </div>
            </div>
        );
    }

    return (
        <button 
            onClick={() => setIsConfirming(true)}
            className="w-full flex justify-between items-center p-3 rounded-lg border border-red-100 dark:border-red-900/30 bg-white dark:bg-zinc-900 cursor-pointer hover:bg-red-50 dark:hover:bg-red-900/10 transition-colors group"
        >
            <div className="flex items-center gap-3">
                <div className="p-1.5 bg-red-100 dark:bg-red-900/30 rounded-md text-red-500 group-hover:text-red-600 transition-colors">
                    <Trash2 size={14} />
                </div>
                <span className="font-medium text-sm text-red-600/80 dark:text-red-400/80 group-hover:text-red-600 dark:group-hover:text-red-400 transition-colors">{t.deleteAccount}</span>
            </div>
        </button>
    );
};

export default App;
